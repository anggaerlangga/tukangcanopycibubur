// $(document).ready(function() {

//     $('.menu-collapsed').on('click', function() {
//         $('#sidebar, #content').toggleClass('active');
//         $('.collapse.in').toggleClass('in');
//         $('a[aria-expanded=true]').attr('aria-expanded', 'false');
//     });
// });

$(document).ready(function(){
    $(".menu-collapsed").click(function(){
      // $("#submenu1").slideDown("slow");
      alert("hi");
    });

    // $(".menu-collapsed").click(function(){
    //     $("#submenu1").slideUp("slow");
    // });
});